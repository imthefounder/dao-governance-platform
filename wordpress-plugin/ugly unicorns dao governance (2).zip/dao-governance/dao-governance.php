<?php
/**
 * Plugin Name: Ugly Unicorns DAO Platform
 * Plugin URI: https://uglyunicornsdao.com
 * Description: Complete DAO governance platform with gamification, analytics, and social features for the Ugly Unicorns community. Includes membership levels, achievements, treasury analytics, and community discussions.
 * Version: 2.0.0
 * Author: Ugly Unicorns DAO Team
 * Author URI: https://uglyunicornsdao.com
 * License: MIT
 * Text Domain: dao-governance
 * Domain Path: /languages
 * Requires at least: 6.0
 * Tested up to: 6.4
 * Requires PHP: 8.0
 * Network: false
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('DAO_GOVERNANCE_VERSION', '2.0.0');
define('DAO_GOVERNANCE_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DAO_GOVERNANCE_PLUGIN_PATH', plugin_dir_path(__FILE__));

/**
 * Main DAO Governance Plugin Class
 */
class DAOGovernancePlugin {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        
        // Register shortcodes
        add_shortcode('dao_dashboard', array($this, 'dao_dashboard_shortcode'));
        add_shortcode('dao_proposals', array($this, 'dao_proposals_shortcode'));
        add_shortcode('dao_treasury', array($this, 'dao_treasury_shortcode'));
        add_shortcode('dao_governance', array($this, 'dao_governance_shortcode'));
        add_shortcode('wallet_connect', array($this, 'wallet_connect_shortcode'));
        
        // New feature shortcodes
        add_shortcode('dao_gamification', array($this, 'dao_gamification_shortcode'));
        add_shortcode('dao_membership_levels', array($this, 'dao_membership_levels_shortcode'));
        add_shortcode('dao_achievements', array($this, 'dao_achievements_shortcode'));
        add_shortcode('dao_seasonal_challenges', array($this, 'dao_seasonal_challenges_shortcode'));
        add_shortcode('dao_analytics', array($this, 'dao_analytics_shortcode'));
        add_shortcode('dao_governance_analytics', array($this, 'dao_governance_analytics_shortcode'));
        add_shortcode('dao_treasury_analytics', array($this, 'dao_treasury_analytics_shortcode'));
        add_shortcode('dao_profile', array($this, 'dao_profile_shortcode'));
        add_shortcode('dao_personal_dashboard', array($this, 'dao_personal_dashboard_shortcode'));
        add_shortcode('dao_community', array($this, 'dao_community_shortcode'));
        add_shortcode('dao_social_features', array($this, 'dao_social_features_shortcode'));
        add_shortcode('dao_discussions', array($this, 'dao_discussions_shortcode'));
        add_shortcode('dao_leaderboard', array($this, 'dao_leaderboard_shortcode'));
        
        // Register REST API endpoints
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        
        // Admin menu
        add_action('admin_menu', array($this, 'admin_menu'));
        
        // Custom post types for discussions
        add_action('init', array($this, 'register_post_types'));
        
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, 'deactivate');
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load text domain for translations
        load_plugin_textdomain('dao-governance', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        
        // Initialize database tables if needed
        $this->maybe_create_tables();
    }
    
    /**
     * Enqueue JavaScript files
     */
    public function enqueue_scripts() {
        // Only load on pages with DAO content
        if ($this->should_load_assets()) {
            // Web3 libraries
            wp_enqueue_script(
                'ethers-js',
                'https://cdn.ethers.io/lib/ethers-5.7.2.umd.min.js',
                array(),
                '5.7.2',
                true
            );
            
            // Main DAO JavaScript
            wp_enqueue_script(
                'dao-governance-main',
                DAO_GOVERNANCE_PLUGIN_URL . 'assets/js/dao-governance.js',
                array('jquery', 'ethers-js'),
                DAO_GOVERNANCE_VERSION,
                true
            );
            
            // Localize script with contract addresses and settings
            wp_localize_script('dao-governance-main', 'daoGovernance', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('dao_governance_nonce'),
                'contracts' => $this->get_contract_addresses(),
                'chainId' => get_option('dao_chain_id', 8453), // Base Mainnet
                'debug' => WP_DEBUG,
            ));
        }
    }
    
    /**
     * Enqueue CSS files
     */
    public function enqueue_styles() {
        if ($this->should_load_assets()) {
            wp_enqueue_style(
                'dao-governance-style',
                DAO_GOVERNANCE_PLUGIN_URL . 'assets/css/dao-governance.css',
                array(),
                DAO_GOVERNANCE_VERSION
            );
        }
    }
    
    /**
     * Check if DAO assets should be loaded
     */
    private function should_load_assets() {
        global $post;
        
        if (!$post) return false;
        
        // Check for DAO shortcodes in content
        $dao_shortcodes = array('dao_dashboard', 'dao_proposals', 'dao_treasury', 'dao_governance', 'wallet_connect');
        
        foreach ($dao_shortcodes as $shortcode) {
            if (has_shortcode($post->post_content, $shortcode)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get contract addresses from options
     */
    private function get_contract_addresses() {
        return array(
            'govToken' => get_option('dao_gov_token_address', ''),
            'daoGovernor' => get_option('dao_governor_address', ''),
            'timelock' => get_option('dao_timelock_address', ''),
            'proposalManager' => get_option('dao_proposal_manager_address', ''),
            'treasury' => get_option('dao_treasury_address', ''),
            'votingPowerExchange' => get_option('dao_voting_power_exchange_address', ''),
            'uglyUnicornsGovernance' => get_option('dao_ugly_unicorns_governance_address', ''),
            'minchynWrapper' => get_option('dao_minchyn_wrapper_address', ''),
        );
    }
    
    /**
     * DAO Dashboard Shortcode
     */
    public function dao_dashboard_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-dashboard',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/dashboard.php';
        return ob_get_clean();
    }
    
    /**
     * DAO Proposals Shortcode
     */
    public function dao_proposals_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-proposals',
            'limit' => 10,
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/proposals.php';
        return ob_get_clean();
    }
    
    /**
     * DAO Treasury Shortcode
     */
    public function dao_treasury_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-treasury',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/treasury.php';
        return ob_get_clean();
    }
    
    /**
     * DAO Governance Shortcode
     */
    public function dao_governance_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-governance',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/governance.php';
        return ob_get_clean();
    }
    
    /**
     * Wallet Connect Shortcode
     */
    public function wallet_connect_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'wallet-connect',
            'text' => 'Connect Wallet',
        ), $atts);
        
        return '<button class="' . esc_attr($atts['class']) . ' dao-connect-wallet">' . esc_html($atts['text']) . '</button>';
    }
    
    // ===== NEW GAMIFICATION SHORTCODES =====
    
    /**
     * Gamification Dashboard Shortcode
     */
    public function dao_gamification_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-gamification',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/gamification.php';
        return ob_get_clean();
    }
    
    /**
     * Membership Levels Shortcode
     */
    public function dao_membership_levels_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-membership-levels',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/membership-levels.php';
        return ob_get_clean();
    }
    
    /**
     * Achievements Shortcode
     */
    public function dao_achievements_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-achievements',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/achievements.php';
        return ob_get_clean();
    }
    
    /**
     * Seasonal Challenges Shortcode
     */
    public function dao_seasonal_challenges_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-seasonal-challenges',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/seasonal-challenges.php';
        return ob_get_clean();
    }
    
    // ===== NEW ANALYTICS SHORTCODES =====
    
    /**
     * Analytics Dashboard Shortcode
     */
    public function dao_analytics_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-analytics',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/analytics.php';
        return ob_get_clean();
    }
    
    /**
     * Governance Analytics Shortcode
     */
    public function dao_governance_analytics_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-governance-analytics',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/governance-analytics.php';
        return ob_get_clean();
    }
    
    /**
     * Treasury Analytics Shortcode
     */
    public function dao_treasury_analytics_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-treasury-analytics',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/treasury-analytics.php';
        return ob_get_clean();
    }
    
    // ===== NEW MEMBER FEATURES SHORTCODES =====
    
    /**
     * Profile Dashboard Shortcode
     */
    public function dao_profile_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-profile',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/profile.php';
        return ob_get_clean();
    }
    
    /**
     * Personal Dashboard Shortcode
     */
    public function dao_personal_dashboard_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-personal-dashboard',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/personal-dashboard.php';
        return ob_get_clean();
    }
    
    /**
     * Community Features Shortcode
     */
    public function dao_community_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-community',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/community.php';
        return ob_get_clean();
    }
    
    /**
     * Social Features Shortcode
     */
    public function dao_social_features_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-social-features',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/social-features.php';
        return ob_get_clean();
    }
    
    /**
     * Discussions Shortcode
     */
    public function dao_discussions_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-discussions',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/discussions.php';
        return ob_get_clean();
    }
    
    /**
     * Leaderboard Shortcode
     */
    public function dao_leaderboard_shortcode($atts) {
        $atts = shortcode_atts(array(
            'class' => 'dao-leaderboard',
        ), $atts);
        
        ob_start();
        include DAO_GOVERNANCE_PLUGIN_PATH . 'templates/leaderboard.php';
        return ob_get_clean();
    }
    
    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        register_rest_route('dao-governance/v1', '/proposals', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_proposals'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route('dao-governance/v1', '/treasury', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_treasury_data'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route('dao-governance/v1', '/user/(?P<address>[a-zA-Z0-9]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_user_data'),
            'permission_callback' => '__return_true',
        ));
        
        // New endpoints for enhanced features
        register_rest_route('dao-governance/v1', '/gamification/(?P<address>[a-zA-Z0-9]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_gamification_data'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route('dao-governance/v1', '/analytics/governance', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_governance_analytics'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route('dao-governance/v1', '/analytics/treasury', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_treasury_analytics'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route('dao-governance/v1', '/discussions', array(
            'methods' => array('GET', 'POST'),
            'callback' => array($this, 'handle_discussions'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route('dao-governance/v1', '/leaderboard', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_leaderboard'),
            'permission_callback' => '__return_true',
        ));
    }
    
    /**
     * Register custom post types
     */
    public function register_post_types() {
        // DAO Discussion post type
        register_post_type('dao_discussion', array(
            'labels' => array(
                'name' => 'DAO Discussions',
                'singular_name' => 'DAO Discussion',
                'add_new' => 'Add New Discussion',
                'add_new_item' => 'Add New Discussion',
                'edit_item' => 'Edit Discussion',
                'new_item' => 'New Discussion',
                'view_item' => 'View Discussion',
                'search_items' => 'Search Discussions',
                'not_found' => 'No discussions found',
                'not_found_in_trash' => 'No discussions found in trash',
            ),
            'public' => true,
            'has_archive' => true,
            'show_in_rest' => true,
            'supports' => array('title', 'editor', 'author', 'comments', 'custom-fields'),
            'menu_icon' => 'dashicons-format-chat',
            'capability_type' => 'post',
        ));
        
        // DAO Achievement post type
        register_post_type('dao_achievement', array(
            'labels' => array(
                'name' => 'DAO Achievements',
                'singular_name' => 'DAO Achievement',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_admin_bar' => false,
            'show_in_rest' => true,
            'supports' => array('title', 'editor', 'custom-fields'),
            'menu_icon' => 'dashicons-awards',
        ));
    }
    
    /**
     * Get proposals via REST API
     */
    public function get_proposals($request) {
        // This would typically fetch from blockchain or cache
        return rest_ensure_response(array(
            'proposals' => array(),
            'total' => 0,
            'success' => true,
        ));
    }
    
    /**
     * Get treasury data via REST API
     */
    public function get_treasury_data($request) {
        return rest_ensure_response(array(
            'assets' => array(),
            'totalValue' => 0,
            'success' => true,
        ));
    }
    
    /**
     * Get user data via REST API
     */
    public function get_user_data($request) {
        $address = $request->get_param('address');
        
        return rest_ensure_response(array(
            'address' => $address,
            'votingPower' => 0,
            'proposals' => array(),
            'success' => true,
        ));
    }
    
    // ===== NEW API METHODS =====
    
    /**
     * Get gamification data for user
     */
    public function get_gamification_data($request) {
        $address = $request->get_param('address');
        
        // Sample gamification data - would typically come from blockchain/database
        return rest_ensure_response(array(
            'address' => $address,
            'membershipLevel' => array(
                'current' => 'Contributor',
                'tier' => 2,
                'progress' => 75,
                'totalXP' => 750,
                'requiredXP' => 1000,
            ),
            'achievements' => array(
                array('id' => 1, 'name' => 'First Vote', 'unlocked' => true, 'date' => '2024-01-15'),
                array('id' => 2, 'name' => 'Proposal Creator', 'unlocked' => true, 'date' => '2024-02-01'),
                array('id' => 3, 'name' => 'Community Builder', 'unlocked' => false, 'progress' => 60),
            ),
            'seasonalChallenges' => array(
                array('id' => 1, 'name' => 'January Governance Sprint', 'progress' => 80, 'reward' => 50),
                array('id' => 2, 'name' => 'Community Engagement', 'progress' => 60, 'reward' => 30),
            ),
            'success' => true,
        ));
    }
    
    /**
     * Get governance analytics
     */
    public function get_governance_analytics($request) {
        return rest_ensure_response(array(
            'participationRate' => 68.5,
            'averageVotingPower' => 125.8,
            'activeProposals' => 7,
            'totalProposals' => 156,
            'passedProposals' => 128,
            'rejectedProposals' => 21,
            'recentActivity' => array(
                array('type' => 'vote', 'timestamp' => time() - 3600, 'user' => '0x123...abc'),
                array('type' => 'proposal', 'timestamp' => time() - 7200, 'user' => '0x456...def'),
            ),
            'success' => true,
        ));
    }
    
    /**
     * Get treasury analytics
     */
    public function get_treasury_analytics($request) {
        return rest_ensure_response(array(
            'totalValue' => 2450000,
            'monthlyChange' => 12.5,
            'assets' => array(
                array('symbol' => 'ETH', 'amount' => 850, 'value' => 2125000),
                array('symbol' => 'USDC', 'amount' => 325000, 'value' => 325000),
            ),
            'expenses' => array(
                array('category' => 'Development', 'amount' => 45000, 'percentage' => 65),
                array('category' => 'Marketing', 'amount' => 15000, 'percentage' => 22),
                array('category' => 'Operations', 'amount' => 9000, 'percentage' => 13),
            ),
            'performanceHistory' => array(
                array('month' => '2024-01', 'value' => 2200000),
                array('month' => '2024-02', 'value' => 2350000),
                array('month' => '2024-03', 'value' => 2450000),
            ),
            'success' => true,
        ));
    }
    
    /**
     * Handle discussions (GET/POST)
     */
    public function handle_discussions($request) {
        if ($request->get_method() === 'GET') {
            $discussions = get_posts(array(
                'post_type' => 'dao_discussion',
                'posts_per_page' => 10,
                'post_status' => 'publish',
            ));
            
            $formatted_discussions = array();
            foreach ($discussions as $discussion) {
                $formatted_discussions[] = array(
                    'id' => $discussion->ID,
                    'title' => $discussion->post_title,
                    'content' => $discussion->post_content,
                    'author' => get_the_author_meta('display_name', $discussion->post_author),
                    'date' => $discussion->post_date,
                    'comments_count' => wp_count_comments($discussion->ID)->approved,
                );
            }
            
            return rest_ensure_response(array(
                'discussions' => $formatted_discussions,
                'success' => true,
            ));
        } else if ($request->get_method() === 'POST') {
            // Handle new discussion creation
            $title = sanitize_text_field($request->get_param('title'));
            $content = wp_kses_post($request->get_param('content'));
            $author_address = sanitize_text_field($request->get_param('author_address'));
            
            $discussion_id = wp_insert_post(array(
                'post_title' => $title,
                'post_content' => $content,
                'post_type' => 'dao_discussion',
                'post_status' => 'publish',
                'meta_input' => array(
                    'author_address' => $author_address,
                ),
            ));
            
            return rest_ensure_response(array(
                'discussion_id' => $discussion_id,
                'success' => !is_wp_error($discussion_id),
            ));
        }
    }
    
    /**
     * Get leaderboard data
     */
    public function get_leaderboard($request) {
        return rest_ensure_response(array(
            'leaders' => array(
                array('address' => '0x123...abc', 'name' => 'Alice', 'xp' => 1250, 'level' => 'Advocate', 'votes' => 45),
                array('address' => '0x456...def', 'name' => 'Bob', 'xp' => 980, 'level' => 'Contributor', 'votes' => 32),
                array('address' => '0x789...ghi', 'name' => 'Charlie', 'xp' => 875, 'level' => 'Contributor', 'votes' => 28),
                array('address' => '0xabc...123', 'name' => 'Diana', 'xp' => 750, 'level' => 'Member', 'votes' => 22),
                array('address' => '0xdef...456', 'name' => 'Eve', 'xp' => 620, 'level' => 'Member', 'votes' => 18),
            ),
            'userRank' => 12,
            'totalMembers' => 156,
            'success' => true,
        ));
    }
    
    /**
     * Add admin menu
     */
    public function admin_menu() {
        add_menu_page(
            'DAO Governance',
            'DAO Governance',
            'manage_options',
            'dao-governance',
            array($this, 'admin_page'),
            'dashicons-groups',
            30
        );
    }
    
    /**
     * Admin page callback
     */
    public function admin_page() {
        include DAO_GOVERNANCE_PLUGIN_PATH . 'admin/admin-page.php';
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables if needed
        $this->maybe_create_tables();
        
        // Set default options
        $default_options = array(
            'dao_chain_id' => 8453, // Base Mainnet
            'dao_enable_logging' => true,
            'dao_cache_duration' => 300, // 5 minutes
        );
        
        foreach ($default_options as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public static function deactivate() {
        // Clean up if needed
        flush_rewrite_rules();
    }
    
    /**
     * Create database tables if needed
     */
    private function maybe_create_tables() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'dao_governance_cache';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            cache_key varchar(255) NOT NULL,
            cache_value longtext NOT NULL,
            expires datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY cache_key (cache_key)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

// Initialize the plugin
DAOGovernancePlugin::get_instance();

/**
 * Helper function to get plugin instance
 */
function dao_governance() {
    return DAOGovernancePlugin::get_instance();
}